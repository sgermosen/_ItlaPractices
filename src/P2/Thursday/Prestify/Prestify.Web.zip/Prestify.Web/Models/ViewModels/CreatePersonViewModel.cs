﻿namespace Prestify.Web.Models.ViewModels
{
    public class CreatePersonViewModel: PersonViewModel
    {
    }
}
