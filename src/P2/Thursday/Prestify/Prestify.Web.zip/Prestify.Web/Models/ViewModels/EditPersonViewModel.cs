﻿namespace Prestify.Web.Models.ViewModels
{
    public class EditPersonViewModel: PersonViewModel
    {
        public int Id { get; set; }
    }
}
